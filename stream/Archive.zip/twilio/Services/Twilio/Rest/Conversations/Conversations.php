<?php

class Services_Twilio_Rest_Conversations_Conversations extends
    Services_Twilio_ConversationsListResource {
}
