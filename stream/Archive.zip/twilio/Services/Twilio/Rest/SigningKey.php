<?php

class Services_Twilio_Rest_SigningKey extends Services_Twilio_InstanceResource
{
}
